package com.example.hw_7_m2;

public enum Operation {
    PLUS, MINIS, DELIT, MULTIPLY
}
